import { lazy, Suspense } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import Hero from './components/Hero'

const Home = lazy(() => import('./pages/Home'))
const QuemSomos = lazy(() => import('./pages/QuemSomos'))
const Cardapio = lazy(() => import('./pages/Cardapio'))
const Restaurante = lazy(() => import('./pages/Restaurante'))
const InstalarPWA = lazy(() => import('./pages/InstalarPWA'))
const Contacto = lazy(() => import('./pages/Contacto'))
const FacaParte = lazy(() => import('./pages/FacaParte'))
const Colaborador = lazy(() => import('./pages/Colaborador'))
const Privacidade = lazy(() => import('./pages/legal/Privacidade'))
const Cookies = lazy(() => import('./pages/legal/Cookies'))
const Termos = lazy(() => import('./pages/legal/Termos'))
const CondicoesVenda = lazy(() => import('./pages/legal/CondicoesVenda'))
const EquipaLayout = lazy(() => import('./pages/equipa/EquipaLayout'))
const Staff = lazy(() => import('./pages/equipa/Staff'))
const Operacional = lazy(() => import('./pages/equipa/Operacional'))
const Ecra = lazy(() => import('./pages/equipa/Ecra'))
const Admin = lazy(() => import('./pages/equipa/Admin'))
const CaixaPdv = lazy(() => import('./pages/CaixaPdv'))
const VisorCliente = lazy(() => import('./pages/VisorCliente'))

const fallbackClaro = <div className="min-h-dvh bg-creme-50" />
const fallbackEscuro = <div className="min-h-dvh bg-grafite-950" />

const pagina = (Componente) => (
  <Suspense fallback={fallbackClaro}>
    <Componente />
  </Suspense>
)
const interna = (Componente) => (
  <Suspense fallback={fallbackEscuro}>
    <Componente />
  </Suspense>
)

function App() {
  return (
    <Routes>
        {/* Site público */}
        <Route element={<Layout />}>
          <Route path="/" element={<Hero />} />
          <Route path="/home" element={pagina(Home)} />
          <Route path="/quem-somos" element={pagina(QuemSomos)} />
          <Route path="/cardapio" element={pagina(Cardapio)} />
          <Route path="/restaurante" element={pagina(Restaurante)} />
          {/* Endereço curto para caber num QR impresso e ser escrito à mão */}
          <Route path="/app" element={pagina(InstalarPWA)} />
          <Route path="/contacto" element={pagina(Contacto)} />
          <Route path="/faca-parte" element={pagina(FacaParte)} />
          <Route path="/colaborador" element={pagina(Colaborador)} />
          <Route path="/colaboradores" element={<Navigate to="/colaborador" replace />} />
          {/* Páginas legais */}
          <Route path="/privacidade" element={pagina(Privacidade)} />
          <Route path="/cookies" element={pagina(Cookies)} />
          <Route path="/termos" element={pagina(Termos)} />
          <Route path="/condicoes-venda" element={pagina(CondicoesVenda)} />
          {/* Rota antiga — o cardápio mudou de endereço */}
          <Route path="/conhecer-a-casa" element={<Navigate to="/cardapio" replace />} />
          {/* Rota antiga — grafia brasileira corrigida para PT-PT (2026-07-20) */}
          <Route path="/contato" element={<Navigate to="/contacto" replace />} />
        </Route>

        {/* Ecrã público (TV) — sem auth nem PIN, só mostra números de pedido */}
        <Route path="/ecran" element={interna(Ecra)} />

        {/* PDV — caixa registadora (auth própria + PIN) */}
        <Route path="/caixa" element={interna(CaixaPdv)} />
        {/* Visor do cliente — tablet junto à caixa (sem auth) */}
        <Route path="/visor" element={interna(VisorCliente)} />

        {/* Área da equipa — Supabase Auth + PIN de conveniência */}
        <Route element={interna(EquipaLayout)}>
          <Route path="/staff" element={interna(Staff)} />
          <Route path="/operacional" element={interna(Operacional)} />
          <Route path="/admin" element={interna(Admin)} />
        </Route>

        {/* Rotas antigas da fase 2 */}
        <Route path="/equipa" element={<Navigate to="/staff" replace />} />
        <Route path="/equipa/staff" element={<Navigate to="/staff" replace />} />
        <Route path="/equipa/operacional" element={<Navigate to="/operacional" replace />} />
        <Route path="/equipa/admin" element={<Navigate to="/admin" replace />} />
        <Route path="/equipa/ecra" element={<Navigate to="/ecran" replace />} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default App
