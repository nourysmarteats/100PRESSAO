import { useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import logoStamp from '../assets/logo-100pressao.png'

// Partilhado com o rodapé (Footer importa daqui), para as duas navegações
// nunca divergirem. "Encomendar" fica ao lado da "Ementa" por serem as duas
// acções comerciais: ver o que há, e pedir para casa.
//
// "Ementa" passou a apontar para /ementa (2026-08-15), a página pública e
// estática, em vez de /cardapio, que é o sistema de pedidos à mesa e só mostra
// o menu depois de pedir nome e lugar. Além de ser o que o visitante espera ao
// clicar em "Ementa", dá à página indexável os links internos de que precisa
// para o Google a considerar importante. O /cardapio continua acessível pelo QR
// das mesas e pelo botão dentro da própria ementa.
//
// externo: true → o alvo é HTML estático fora do React Router, tem de ser um
// <a> normal. Um <Link> faria o router tentar resolver a rota e cair no
// redirecionamento para "/".
export const NAV_LINKS = [
  { to: '/', label: 'Início' },
  { to: '/quem-somos', label: 'Quem Somos' },
  { to: '/ementa', label: 'Ementa', externo: true },
  { to: '/restaurante', label: 'Encomendar' },
  { to: '/contacto', label: 'Contacto' },
  { to: '/faca-parte', label: 'Faça Parte' },
]

function Header() {
  const [aberto, setAberto] = useState(false)
  const { pathname } = useLocation()
  const escuro = pathname === '/' // home: header sobreposto ao Hero escuro

  const corBase = escuro ? 'text-creme-100' : 'text-grafite-800'
  const corAtiva = escuro ? 'text-ambar-400' : 'text-cobre-600'

  return (
    <header
      className={
        escuro
          ? 'absolute inset-x-0 top-0 z-40'
          : 'sticky top-0 z-40 border-b border-creme-300 bg-creme-50/90 backdrop-blur'
      }
    >
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
        <Link to="/" className="flex items-center gap-4" onClick={() => setAberto(false)}>
          <img
            src={logoStamp}
            alt="Logótipo 100PRESSÃO Draft House"
            width="640"
            height="640"
            className={`h-16 w-16 rounded-full sm:h-20 sm:w-20 ${escuro ? 'mix-blend-lighten' : ''}`}
          />
          <span
            className={`font-display text-xl font-bold uppercase tracking-tight sm:text-2xl ${escuro ? 'text-creme-50' : 'text-grafite-900'}`}
          >
            100PRESSÃO
          </span>
        </Link>

        {/* Desktop */}
        {/* Com 6 itens já não cabe a 768px ao lado do logótipo — o menu completo
            passa a aparecer só a partir de lg; abaixo disso fica o hambúrguer. */}
        <nav className="hidden items-center gap-6 lg:flex xl:gap-8" aria-label="Navegação principal">
          {NAV_LINKS.map((l) => {
            const classe = `text-sm font-semibold uppercase tracking-widest transition-colors duration-200 hover:${corAtiva}`
            return l.externo ? (
              <a key={l.to} href={l.to} className={`${classe} ${corBase}`}>
                {l.label}
              </a>
            ) : (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) => `${classe} ${isActive ? corAtiva : corBase}`}
              >
                {l.label}
              </NavLink>
            )
          })}
        </nav>

        {/* Mobile: hambúrguer */}
        <button
          type="button"
          onClick={() => setAberto((v) => !v)}
          aria-expanded={aberto}
          aria-label={aberto ? 'Fechar menu' : 'Abrir menu'}
          className={`cursor-pointer p-2 lg:hidden ${corBase}`}
        >
          <svg
            className="h-7 w-7"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            {aberto ? (
              <path d="M6 6l12 12M18 6L6 18" />
            ) : (
              <path d="M4 7h16M4 12h16M4 17h16" />
            )}
          </svg>
        </button>
      </div>

      <AnimatePresence>
        {aberto && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            aria-label="Navegação principal (móvel)"
            className={`overflow-hidden lg:hidden ${escuro ? 'bg-grafite-950/95' : 'border-b border-creme-300 bg-creme-50'}`}
          >
            <ul className="space-y-1 px-6 py-4">
              {NAV_LINKS.map((l) => {
                const classe = 'block py-3 text-base font-semibold uppercase tracking-widest'
                return (
                  <li key={l.to}>
                    {l.externo ? (
                      <a href={l.to} className={`${classe} ${corBase}`}>
                        {l.label}
                      </a>
                    ) : (
                      <NavLink
                        to={l.to}
                        onClick={() => setAberto(false)}
                        className={({ isActive }) =>
                          `${classe} ${isActive ? corAtiva : corBase}`
                        }
                      >
                        {l.label}
                      </NavLink>
                    )}
                  </li>
                )
              })}
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  )
}

export default Header
